<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>DAWBI-M07 PE1</title>
    </head>
    <body>
        <?php include_once "mainmenu.php"; ?>
        <h2>Home page</h2>
        <p>Page under construction!</p>
        <img src="images/shopping.jpg" alt="Shop photograph" height="400" width="600">
        <?php include_once "footer.php"; ?>
    </body>
</html>
