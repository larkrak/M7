<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../style/index.css">
</head>
<body>

<div class="footer">
        <div>
            <i class="fab fa-facebook"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-youtube"></i>
        </div>
        <div class="about">
            <ul>
                <li><a>Sobre nosotros</a></li>
                <li><a>Trabaja con nosotros</a></li>
                <li><a>Encuentranos</a></li>
            </ul>
            <ul>
                <li><a>Nuestra carta</a></li>
                <li><a>Compromiso medioambiental</a></li>
                <li><a>Nuestras carnes</a></li>
            </ul>
            <ul>
                <li><a>Aviso legal</a></li>
                <li><a>Cookies</a></li>
            </ul>
        </div>
        <div><p>Todos los derechos reservados</p></div>
    </div>

</div>
    
</body>
</html>