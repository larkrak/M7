<?php

interface Speaker{
    public function talk();
}


?>